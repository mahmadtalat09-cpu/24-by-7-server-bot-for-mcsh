# HUN CLAN — MCSH 24/7 Server Helper

This repository contains a small helper bot for checking a Minecraft server's status. It **cannot force a hosting provider to keep a server online**. 24/7 uptime depends on your MCSH plan and panel settings.

## Features
- Checks a Minecraft Java server's status on demand.
- Optional Discord bot command `!serverstatus`.
- Can run on a computer or a supported bot-hosting service.
- Does not start, restart, or modify your MCSH server.

## Requirements
- Python 3.11+
- A Discord bot token only if using the Discord integration
- Your Minecraft server address (for example, `your-server.example:25565`)

## Run locally
1. Install Python 3.11 or newer.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and fill in the settings.
4. Run:
   ```bash
   python bot.py
   ```

## Discord setup
1. Create a bot in the Discord Developer Portal and enable **Message Content Intent** if you want to use the `!serverstatus` prefix command.
2. Invite it with only the permissions it needs (View Channels, Send Messages, Embed Links).
3. Put the bot token in `.env` as `DISCORD_TOKEN`. Never commit `.env` or share the token.
4. Set `MINECRAFT_SERVER` to your server hostname, optionally with `:port`.
5. Run the script on a computer or hosting service that supports a persistent Python process.

## About 24/7 uptime
A Discord bot cannot prevent MCSH from sleeping or shutting down a Minecraft server. Check your MCSH plan for an always-on option and disable idle-pause/auto-sleep only if the host explicitly supports it. Do not use fake player bots or repeated pings to bypass host limits.
