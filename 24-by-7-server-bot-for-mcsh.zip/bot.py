import os
import asyncio
from dotenv import load_dotenv
from mcstatus import JavaServer
import discord
from discord.ext import commands

load_dotenv()

SERVER_ADDRESS = os.getenv("MINECRAFT_SERVER", "").strip()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("DISCORD_PREFIX", "!")


def get_status():
    if not SERVER_ADDRESS or SERVER_ADDRESS.startswith("your-server-address"):
        return "Set MINECRAFT_SERVER in your .env file first."
    try:
        server = JavaServer.lookup(SERVER_ADDRESS)
        status = server.status()
        names = [p.name for p in (status.players.sample or [])]
        names_text = ", ".join(names[:10]) if names else "No player names reported"
        return (
            f"**Online** — {status.players.online}/{status.players.max} players\n"
            f"**Latency:** {status.latency:.0f} ms\n"
            f"**Players:** {names_text}"
        )
    except Exception:
        return (
            "**Offline or unreachable.** This may mean the server is stopped, "
            "the address/port is incorrect, or the host blocks status queries."
        )


async def main():
    if not TOKEN:
        print("Discord token not set. Checking Minecraft status once:")
        print(get_status())
        print("\nTo run the Discord bot, set DISCORD_TOKEN in your .env file.")
        return

    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix=PREFIX, intents=intents)

    @bot.event
    async def on_ready():
        print(f"Logged in as {bot.user}. Use {PREFIX}serverstatus in Discord.")

    @bot.command(name="serverstatus")
    async def serverstatus(ctx):
        async with ctx.typing():
            result = await asyncio.to_thread(get_status)
        await ctx.reply(result, mention_author=False)

    await bot.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
